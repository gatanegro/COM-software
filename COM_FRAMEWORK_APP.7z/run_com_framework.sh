#!/bin/bash
cd ~/com_framework
python3 com_framework_app.py
